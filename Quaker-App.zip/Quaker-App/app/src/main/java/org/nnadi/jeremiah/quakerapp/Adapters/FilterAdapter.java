package org.nnadi.jeremiah.quakerapp.Adapters;

/*
 - Name: Jeremiah Nnadi
 - StudentID: S1903336
*/

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import org.nnadi.jeremiah.quakerapp.Activities.DetailActivity;
import org.nnadi.jeremiah.quakerapp.Item;
import org.nnadi.jeremiah.quakerapp.R;

import java.util.List;

public class FilterAdapter extends RecyclerView.Adapter<FilterAdapter.Holder> {
    Context context;
    List<Item> itemList;
    int highestIndex;
    int lowestIndex;
    int highestLatitudeId, lowestLatitudeId, highestLongitudeId, lowestLongitudeId;

    public FilterAdapter(Context context, List<Item> itemList, int highestIndex, int lowestIndex, int highestLatitudeId, int lowestLatitudeId, int highestLongitudeId, int lowestLongitudeId) {
        this.context = context;
        this.itemList = itemList;
        this.highestIndex = highestIndex;
        this.lowestIndex = lowestIndex;
        this.highestLatitudeId = highestLatitudeId;
        this.lowestLatitudeId = lowestLatitudeId;
        this.highestLongitudeId = highestLongitudeId;
        this.lowestLongitudeId = lowestLongitudeId;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.earthquake_filter, parent, false);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
//        set values on textViews
        holder.tvMagnitude.setText("M" + itemList.get(position).getMagnitude());
        holder.tvArea.setText("Location: " + itemList.get(position).getLocation());
//        change bar color according to magnitude
        double magnitude = itemList.get(position).getMagnitude();

        if (magnitude <= 0.9 && magnitude > 0.0) {
            holder.bar.setBackgroundColor(ContextCompat.getColor(context, R.color.p_green));
        } else if (magnitude <= 1.5 && magnitude >= 1.0) {
            holder.bar.setBackgroundColor(ContextCompat.getColor(context, R.color.p_blue));
        } else if (magnitude <= 1.9 && magnitude >= 1.6) {
            holder.bar.setBackgroundColor(ContextCompat.getColor(context, R.color.p_yellow));
        } else if (magnitude <= 2.9 && magnitude >= 2.0) {
            holder.bar.setBackgroundColor(ContextCompat.getColor(context, R.color.p_orange));
        } else if (magnitude <= 3.9 && magnitude >= 3.0) {
            holder.bar.setBackgroundColor(ContextCompat.getColor(context, R.color.p_tulip));
        } else if (magnitude <= 5.9 && magnitude >= 4.0) {
            holder.bar.setBackgroundColor(ContextCompat.getColor(context, R.color.p_red));
        } else if (magnitude >= 6.0) {
            holder.bar.setBackgroundColor(ContextCompat.getColor(context, R.color.p_red_plus));
        } else {
            holder.bar.setBackgroundColor(ContextCompat.getColor(context, R.color.p_yellow));
        }


//        set Shallowest or Deepest on textView
        if (itemList.get(position).getId() == lowestIndex) {
            holder.tvLabel.setVisibility(View.VISIBLE);
            holder.tvLabel.setText("Shallowest: " +  itemList.get(position).getDepth() + " km");
        } else if (itemList.get(position).getId()  == highestIndex) {
            holder.tvLabel.setVisibility(View.VISIBLE);
            holder.tvLabel.setText("Deepest: " + itemList.get(position).getDepth() + " km");
        } else {
            holder.tvLabel.setVisibility(View.GONE);
        }
//        set Northerly, Southerly, Easterly and Westerly on textViews
        if (itemList.get(position).getId() == highestLatitudeId) {
            holder.tvLabel2.setVisibility(View.VISIBLE);
            holder.tvLabel2.setText("Most Northerly");
        } else if (itemList.get(position).getId() == lowestLatitudeId) {
            holder.tvLabel2.setVisibility(View.VISIBLE);
            holder.tvLabel2.setText("Most Southerly");
        } else if (itemList.get(position).getId() == highestLongitudeId) {
            holder.tvLabel2.setVisibility(View.VISIBLE);
            holder.tvLabel2.setText("Most Easterly");
        } else if (itemList.get(position).getId() == lowestLongitudeId) {
            holder.tvLabel2.setVisibility(View.VISIBLE);
            holder.tvLabel2.setText("Most Westerly");
        } else {
            holder.tvLabel2.setVisibility(View.GONE);
        }
//        add click listener on itemView
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                get to EarthquakeActivity with item model
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("item", itemList.get(position));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public void reloadData(int highestIndex, int lowestIndex, int highestLatitudeId, int lowestLatitudeId, int highestLongitudeId, int lowestLongitudeId) {
        this.highestIndex = highestIndex;
        this.lowestIndex = lowestIndex;
        this.highestLatitudeId = highestLatitudeId;
        this.lowestLatitudeId = lowestLatitudeId;
        this.highestLongitudeId = highestLongitudeId;
        this.lowestLongitudeId = lowestLongitudeId;
        notifyDataSetChanged();
    }

    public class Holder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvMagnitude, tvLabel, tvLabel2, tvArea;
        View bar;

        public Holder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card_view);
            tvMagnitude = itemView.findViewById(R.id.tv_magnitude);
            tvLabel = itemView.findViewById(R.id.tv_label);
            tvLabel2 = itemView.findViewById(R.id.tv_label2);
            tvArea = itemView.findViewById(R.id.tv_area);
            bar = itemView.findViewById((R.id.bar));
        }
    }
}
