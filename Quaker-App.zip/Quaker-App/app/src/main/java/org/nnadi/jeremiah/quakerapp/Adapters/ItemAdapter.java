package org.nnadi.jeremiah.quakerapp.Adapters;

/*
 - Name: Jeremiah Nnadi
 - StudentID: S1903336
*/

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import org.nnadi.jeremiah.quakerapp.Activities.DetailActivity;
import org.nnadi.jeremiah.quakerapp.Item;
import org.nnadi.jeremiah.quakerapp.R;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.Holder> {
    Context context;
    List<Item> itemList;

    public ItemAdapter(Context context, List<Item> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.earthquake, parent, false);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {

//        set values on textViews
        holder.tvTitle.setText("Location: " + itemList.get(position).getLocation());
        holder.tvMagnitude.setText("M" + itemList.get(position).getMagnitude());
        holder.cDate.setText("Date: " + itemList.get(position).getPubDate());

        //Parse the magnitude of each earthquake item and color-code it accordingly
        double magnitude = itemList.get(position).getMagnitude();

        if (magnitude <= 0.9 && magnitude > 0.0) {
            holder.tvMagnitude.setBackgroundColor(ContextCompat.getColor(context, R.color.p_green));
        } else if (magnitude <= 1.5 && magnitude >= 1.0) {
            holder.tvMagnitude.setBackgroundColor(ContextCompat.getColor(context, R.color.p_blue));
        } else if (magnitude <= 1.9 && magnitude >= 1.6) {
            holder.tvMagnitude.setBackgroundColor(ContextCompat.getColor(context, R.color.p_yellow));
        } else if (magnitude <= 2.9 && magnitude >= 2.0) {
            holder.tvMagnitude.setBackgroundColor(ContextCompat.getColor(context, R.color.p_orange));
        } else if (magnitude <= 3.9 && magnitude >= 3.0) {
            holder.tvMagnitude.setBackgroundColor(ContextCompat.getColor(context, R.color.p_tulip));
        } else if (magnitude <= 5.9 && magnitude >= 4.0) {
            holder.tvMagnitude.setBackgroundColor(ContextCompat.getColor(context, R.color.p_red));
        } else if (magnitude >= 6.0) {
            holder.tvMagnitude.setBackgroundColor(ContextCompat.getColor(context, R.color.p_red_plus));
        } else {
            holder.tvMagnitude.setBackgroundColor(ContextCompat.getColor(context, R.color.yellow));
        }

//        add click listener on itemView
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                get to DetailActivity with item model
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("item", itemList.get(position));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvTitle, tvMagnitude, cDate;

        public Holder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card_view);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvMagnitude = itemView.findViewById(R.id.tv_magnitude);
            cDate = itemView.findViewById(R.id.tv_date);
        }
    }


}
