package org.nnadi.jeremiah.quakerapp.Activities;

/*
 - Name: Jeremiah Nnadi
 - StudentID: S1903336
*/

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.nnadi.jeremiah.quakerapp.Adapters.FilterAdapter;
import org.nnadi.jeremiah.quakerapp.Item;
import org.nnadi.jeremiah.quakerapp.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FilterActivity extends AppCompatActivity {
    TextView tvSpecificDate, tvRangeDate1, tvRangeDate2;
    Button btnApply;
    RadioButton rbSpecific, rbRange;
    RecyclerView recyclerView;
    FilterAdapter dateAdapter;
    List<Item> itemList = new ArrayList<>();
    int highestIndexId, lowestIndexId, highestLatitudeId, lowestLatitudeId, highestLongitudeId, lowestLongitudeId;

    //     When the back button is clicked, return back to the main menu
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
//        startActivityForResult(myIntent, 0);
//        return true;
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);
//        add itemList data in this class
        itemList.addAll(MainActivity.itemList);
//        add back icon in toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        initialize the widgets
        rbSpecific = findViewById(R.id.rb_specific);
        rbRange = findViewById(R.id.rb_range);
        tvSpecificDate = findViewById(R.id.tv_date);
        tvRangeDate1 = findViewById(R.id.tv_range_date1);
        tvRangeDate2 = findViewById(R.id.tv_range_date2);
        btnApply = findViewById(R.id.btn_apply);
        recyclerView = findViewById(R.id.recycler_view);
//        check list size
        if (itemList.size() > 0) {
//            arrange List according to magnitude
            arrangeList();
//            set DateAdapter on recyclerView
            dateAdapter = new FilterAdapter(FilterActivity.this, itemList, highestIndexId, lowestIndexId, highestLatitudeId, lowestLatitudeId, highestLongitudeId, lowestLongitudeId);
            recyclerView.setLayoutManager(new LinearLayoutManager(FilterActivity.this, LinearLayoutManager.VERTICAL, false));
            recyclerView.setAdapter(dateAdapter);
        }
//        ClickListeners on radio buttons
        rbSpecific.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rbRange.setChecked(false);
            }
        });
        rbRange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rbSpecific.setChecked(false);
            }
        });
//        ClickListeners for date dialog
        tvSpecificDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog(0);
            }
        });
        tvRangeDate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog(1);
            }
        });
        tvRangeDate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog(2);
            }
        });
// Checks which radio button is checked (specific or date range), runs according to user input
        btnApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (rbSpecific.isChecked()) {
                    if (TextUtils.isEmpty(tvSpecificDate.getText().toString())) {
                        Toast.makeText(FilterActivity.this, "Please choose a single specific date", Toast.LENGTH_SHORT).show();
                    } else {
//                        get specific date data
                        getSingleDateData();
                    }
                } else if (rbRange.isChecked()) {
                    if (TextUtils.isEmpty(tvRangeDate1.getText().toString())) {
                        Toast.makeText(FilterActivity.this, "Choose a range start date", Toast.LENGTH_SHORT).show();
                    } else if (TextUtils.isEmpty(tvRangeDate2.getText().toString())) {
                        Toast.makeText(FilterActivity.this, "Choose a range end date", Toast.LENGTH_SHORT).show();
                    } else {
//                        get range data
                        getRangeDateData();
                    }
                }
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    //    create datePickerDialog for selecting date
    public void datePickerDialog(int index) {
        DatePickerDialog mDatePicker;
        final Calendar mCalendar = Calendar.getInstance();
        mDatePicker = new DatePickerDialog(FilterActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                mCalendar.set(Calendar.YEAR, year);
                mCalendar.set(Calendar.MONTH, monthOfYear);
                mCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String formattedDate = new SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(mCalendar.getTime());
                if (index == 0) {
                    tvSpecificDate.setText(formattedDate);
                } else if (index == 1) {
                    tvRangeDate1.setText(formattedDate);
                } else if (index == 2) {
                    tvRangeDate2.setText(formattedDate);
                }
            }
        }, mCalendar.get(Calendar.YEAR), mCalendar.get(Calendar.MONTH), mCalendar.get(Calendar.DAY_OF_MONTH));
        mDatePicker.show();
    }

    //   Checks if both dates in date range are not equal
    public boolean isDateEquals(String eqDateStr, String newDateStr) {
        boolean result = false;
        SimpleDateFormat sdf = new SimpleDateFormat("EEE, d MMM yyyy");
        try {
            Date eqDate = sdf.parse(eqDateStr);
            Date newDate = sdf.parse(newDateStr);
            result = newDate.equals(eqDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return result;
    }

    //   create isDateEqualToRange for checking date are present in between range
    public boolean isDateEqualToRange(String eqDateStr, String startDateStr, String endDateStr) {
        boolean result = false;
        SimpleDateFormat sdf = new SimpleDateFormat("EEE, d MMM yyyy");
        try {
            Date eqDate = sdf.parse(eqDateStr);
            Date startDate = sdf.parse(startDateStr);
            Date endDate = sdf.parse(endDateStr);
            result = (eqDate.equals(startDate) || eqDate.after(startDate)) && (eqDate.equals(endDate) || eqDate.before(endDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return result;
    }

    //    create getSingleDateData method for getting specific date data
    public void getSingleDateData() {
        String eqDateStr = tvSpecificDate.getText().toString();
        itemList.clear();
        itemList.addAll(MainActivity.itemList);
        List<Item> newItemList = new ArrayList<>();
        for (Item item : itemList) {
            if (isDateEquals(item.getPubDate(), eqDateStr)) {
                newItemList.add(item);
            }
        }
        if (newItemList.size() > 0) {
            itemList.clear();
            itemList.addAll(newItemList);
//            arrange List according to magnitude
            arrangeList();
            dateAdapter.reloadData(highestIndexId, lowestIndexId, highestLatitudeId, lowestLatitudeId, highestLongitudeId, lowestLongitudeId);
        } else {
            AlertDialog alertDialog = new AlertDialog.Builder(FilterActivity.this).create();
            alertDialog.setTitle("Try Again");
            alertDialog.setMessage("No earthquakes recorded on " + eqDateStr);
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
            itemList.clear();
        }
        dateAdapter.notifyDataSetChanged();
    }

    //    create getSingleDateData method for getting range date data
    public void getRangeDateData() {
        String startDateStr = tvRangeDate1.getText().toString();
        String endDateStr = tvRangeDate2.getText().toString();
        itemList.clear();
        itemList.addAll(MainActivity.itemList);
        List<Item> newItemList = new ArrayList<>();
        for (Item item : itemList) {
            if (isDateEqualToRange(item.getPubDate(), startDateStr, endDateStr)) {
                newItemList.add(item);
            }
        }
        if (newItemList.size() > 0) {
            itemList.clear();
            itemList.addAll(newItemList);
            //      arrange List according to magnitude
            arrangeList();
            dateAdapter.reloadData(highestIndexId, lowestIndexId, highestLatitudeId, lowestLatitudeId, highestLongitudeId, lowestLongitudeId);
        } else {
            AlertDialog alertDialog = new AlertDialog.Builder(FilterActivity.this).create();
            alertDialog.setTitle("Alert");
            alertDialog.setMessage("No earthquakes were recorded between " + startDateStr + " and " + endDateStr);
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
            itemList.clear();
        }
        dateAdapter.notifyDataSetChanged();
    }

    //    create arrangeList method for arrange the list accordingly to magnitude
    public void arrangeList() {
        Collections.sort(itemList, new Comparator<Item>() {
            public int compare(Item obj1, Item obj2) {
                // ## Descending order
                return Double.compare(obj2.getMagnitude(), obj1.getMagnitude());
            }
        });
        getHighestIndex();
        getLowestIndex();
        getLatitudeId();
        getLongitudeId();
        Log.d("theI", "arrangeList: highestIndexId: " + highestIndexId + " lowestIndexId: " + lowestIndexId);
        Log.d("theI", "arrangeList: highestLatitudeId: " + highestLatitudeId + " lowestLatitudeId: " + lowestLatitudeId +
                " highestLongitudeId: " + highestLongitudeId + " lowestLongitudeId: " + lowestLongitudeId);
        List<Item> itemList1 = new ArrayList<>();
        for (int i = 0; i < itemList.size(); i++) {
            int id = itemList.get(i).getId();
            if (id == highestIndexId || id == lowestIndexId ||
                    id == highestLatitudeId || id == lowestLatitudeId || id == highestLongitudeId || id == lowestLongitudeId) {
                itemList1.add(itemList.get(i));
                Log.d("theI", "arrangeList: i: " + i + " id: " + id);
            }
        }
        itemList.clear();
        itemList.addAll(itemList1);
    }

    //    create getHighestIndex method for getting depth highest value Id
    public void getHighestIndex() {
        double highest = itemList.get(0).getDepth();
        highestIndexId = itemList.get(0).getId();
        for (int s = 1; s < itemList.size(); s++) {
            double curValue = itemList.get(s).getDepth();
            if (curValue > highest) {
                highest = curValue;
                highestIndexId = itemList.get(s).getId();
            }
        }
    }

    //    create getLowestIndex method for getting depth lowest value Id
    public void getLowestIndex() {
        double lowest = itemList.get(0).getDepth();
        lowestIndexId = itemList.get(0).getId();
        for (int s = 1; s < itemList.size(); s++) {
            double curValue = itemList.get(s).getDepth();
            if (curValue < lowest) {
                lowest = curValue;
                lowestIndexId = itemList.get(s).getId();
            }
        }
    }

    //    create getLatitudeId method for getting highest and lowest latitude id
    public void getLatitudeId() {
        double highest = itemList.get(0).getLatitude();
        double lowest = itemList.get(0).getLatitude();
        highestLatitudeId = itemList.get(0).getId();
        lowestLatitudeId = itemList.get(0).getId();
        for (int s = 1; s < itemList.size(); s++) {
            double curValue = itemList.get(s).getLatitude();
            if (curValue > highest) {
                highest = curValue;
                highestLatitudeId = itemList.get(s).getId();
            }
            if (curValue < lowest) {
                lowest = curValue;
                lowestLatitudeId = itemList.get(s).getId();
            }
        }
    }

    //    create getLongitudeId method for getting highest and lowest longitude id
    public void getLongitudeId() {
        double highest = itemList.get(0).getLongitude();
        double lowest = itemList.get(0).getLongitude();
        highestLongitudeId = itemList.get(0).getId();
        lowestLongitudeId = itemList.get(0).getId();
        for (int s = 1; s < itemList.size(); s++) {
            double curValue = itemList.get(s).getLongitude();
            if (curValue > highest) {
                highest = curValue;
                highestLongitudeId = itemList.get(s).getId();
            }
            if (curValue < lowest) {
                lowest = curValue;
                lowestLongitudeId = itemList.get(s).getId();
            }
        }
    }
}